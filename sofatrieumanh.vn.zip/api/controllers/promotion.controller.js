const Promotion = require('../models/promotion.model')
const mongoose = require('mongoose')
const { check, validationResult } = require('express-validator')

module.exports.getAllPromotions = function(req, res) {
  Promotion.find()
    .select({
      promotionName: 1,
      _id: 1,
      createDate: 1,
      modifyDate: 1,
      isHot: 1,
      isActive: 1,
      validDate: 1
    })
    .exec((error, response) => {
      if (error) {
        return next(error)
      } else {
        res.status(200).json(response)
      }
    })
}

module.exports.getSinglePromotion = function(req, res, next) {
  Promotion.findById(req.params.id, (error, data) => {
    if (error) {
      return next(error)
    } else {
      res.status(200).json(data)
    }
  })
}

module.exports.insertPromotion = function(req, res, next) {
  const errors = validationResult(req)

  if (!errors.isEmpty()) {
    return res.status(422).jsonp(errors.array())
  } else {
    const promotion = new Promotion(req.body)
    promotion
      .save()
      .then((response) => {
        res.status(201).json({
          message: 'Promotion successfully created!',
          result: response
        })
      })
      .catch((error) => {
        res.status(500).json({
          error: error
        })
      })
  }
}

module.exports.updatePromotion = function(req, res, next) {
  Promotion.findByIdAndUpdate(
    req.params.id,
    {
      $set: req.body
    },
    (error, data) => {
      if (error) {
        return next(error)
      } else {
        res.json(data)
      }
    }
  )
}

module.exports.deletePromotion = function(req, res, next) {
  Promotion.findByIdAndRemove(req.params.id, (error, data) => {
    if (error) {
      return next(error)
    } else {
      res.status(200).json({
        msg: data
      })
    }
  })
}
