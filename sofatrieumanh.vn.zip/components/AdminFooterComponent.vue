<template>
  <div class="admin__footer__component">
    <div class="row mp--none">
      <div class="col-12 mp--none py-1 text-center">
        <p class="text__size--x08 mp--none">Admin page by sofatrieumanh.com</p>
      </div>
    </div>
  </div>
</template>
<style lang="scss">
.admin__footer__component {
  background-color: $promotion__bg__color;
  color: $white__color;
}
</style>
