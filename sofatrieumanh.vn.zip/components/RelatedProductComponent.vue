<template>
  <div class="related__component">
    <div class="container">
      <div class="row mp--none">
        <div class="col-12 mp--none">
          <h6 class="component__title">San pham co lien quan</h6>
        </div>
      </div>
      <div class="row mp--none">
        <div
          class="col-12 mp--none d-flex justify-content-start align-items-center flex-wrap"
        >
          <div class="card border-0 product__item">
            <div class="card-body p-1">
              <div class="product__item__img product__item__img--04">
                <div class="discount__tag"></div>
              </div>
              <div class="product__item__detail">
                <h6 class="product__item__name">SOFA GÓC CỔ ĐIỂN MÃ 1468</h6>
                <div class="product__item__price">
                  <span class="current__price">2,560,270</span>
                  <span class="discount__price">3,900,000</span>
                </div>
                <div class="product__item__action">
                  <vs-button
                    :color="'#156867'"
                    type="border"
                    class="border__radius--none px-2 py-1 m-1"
                    @click="redirectToComparePage"
                    >So sánh</vs-button
                  >
                  <vs-button
                    :color="'#156867'"
                    type="filled"
                    class="border__radius--none px-2 py-1 m-1 border__primary"
                    @click="redirectToProductPage"
                    >Mua ngay</vs-button
                  >
                </div>
              </div>
            </div>
          </div>
          <div class="card border-0 product__item">
            <div class="card-body p-1">
              <div class="product__item__img product__item__img--04">
                <div class="discount__tag"></div>
              </div>
              <div class="product__item__detail">
                <h6 class="product__item__name">SOFA GÓC CỔ ĐIỂN MÃ 1468</h6>
                <div class="product__item__price">
                  <span class="current__price">2,560,270</span>
                  <span class="discount__price">3,900,000</span>
                </div>
                <div class="product__item__action">
                  <vs-button
                    :color="'#156867'"
                    type="border"
                    class="border__radius--none px-2 py-1 m-1"
                    @click="redirectToComparePage"
                    >So sánh</vs-button
                  >
                  <vs-button
                    :color="'#156867'"
                    type="filled"
                    class="border__radius--none px-2 py-1 m-1 border__primary"
                    @click="redirectToProductPage"
                    >Mua ngay</vs-button
                  >
                </div>
              </div>
            </div>
          </div>
          <div class="card border-0 product__item">
            <div class="card-body p-1">
              <div class="product__item__img product__item__img--04">
                <div class="discount__tag"></div>
              </div>
              <div class="product__item__detail">
                <h6 class="product__item__name">SOFA GÓC CỔ ĐIỂN MÃ 1468</h6>
                <div class="product__item__price">
                  <span class="current__price">2,560,270</span>
                  <span class="discount__price">3,900,000</span>
                </div>
                <div class="product__item__action">
                  <vs-button
                    :color="'#156867'"
                    type="border"
                    class="border__radius--none px-2 py-1 m-1"
                    @click="redirectToComparePage"
                    >So sánh</vs-button
                  >
                  <vs-button
                    :color="'#156867'"
                    type="filled"
                    class="border__radius--none px-2 py-1 m-1 border__primary"
                    @click="redirectToProductPage"
                    >Mua ngay</vs-button
                  >
                </div>
              </div>
            </div>
          </div>
          <div class="card border-0 product__item">
            <div class="card-body p-1">
              <div class="product__item__img product__item__img--04">
                <div class="discount__tag"></div>
              </div>
              <div class="product__item__detail">
                <h6 class="product__item__name">SOFA GÓC CỔ ĐIỂN MÃ 1468</h6>
                <div class="product__item__price">
                  <span class="current__price">2,560,270</span>
                  <span class="discount__price">3,900,000</span>
                </div>
                <div class="product__item__action">
                  <vs-button
                    :color="'#156867'"
                    type="border"
                    class="border__radius--none px-2 py-1 m-1"
                    @click="redirectToComparePage"
                    >So sánh</vs-button
                  >
                  <vs-button
                    :color="'#156867'"
                    type="filled"
                    class="border__radius--none px-2 py-1 m-1 border__primary"
                    @click="redirectToProductPage"
                    >Mua ngay</vs-button
                  >
                </div>
              </div>
            </div>
          </div>
          <div class="card border-0 product__item">
            <div class="card-body p-1">
              <div class="product__item__img product__item__img--04">
                <div class="discount__tag"></div>
              </div>
              <div class="product__item__detail">
                <h6 class="product__item__name">SOFA GÓC CỔ ĐIỂN MÃ 1468</h6>
                <div class="product__item__price">
                  <span class="current__price">2,560,270</span>
                  <span class="discount__price">3,900,000</span>
                </div>
                <div class="product__item__action">
                  <vs-button
                    :color="'#156867'"
                    type="border"
                    class="border__radius--none px-2 py-1 m-1"
                    @click="redirectToComparePage"
                    >So sánh</vs-button
                  >
                  <vs-button
                    :color="'#156867'"
                    type="filled"
                    class="border__radius--none px-2 py-1 m-1 border__primary"
                    @click="redirectToProductPage"
                    >Mua ngay</vs-button
                  >
                </div>
              </div>
            </div>
          </div>
          <div class="card border-0 product__item">
            <div class="card-body p-1">
              <div class="product__item__img product__item__img--04">
                <div class="discount__tag"></div>
              </div>
              <div class="product__item__detail">
                <h6 class="product__item__name">SOFA GÓC CỔ ĐIỂN MÃ 1468</h6>
                <div class="product__item__price">
                  <span class="current__price">2,560,270</span>
                  <span class="discount__price">3,900,000</span>
                </div>
                <div class="product__item__action">
                  <vs-button
                    :color="'#156867'"
                    type="border"
                    class="border__radius--none px-2 py-1 m-1"
                    @click="redirectToComparePage"
                    >So sánh</vs-button
                  >
                  <vs-button
                    :color="'#156867'"
                    type="filled"
                    class="border__radius--none px-2 py-1 m-1 border__primary"
                    @click="redirectToProductPage"
                    >Mua ngay</vs-button
                  >
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  methods: {
    redirectToProductPage() {
      this.$router.replace('/san-pham')
    },
    redirectToComparePage() {
      this.$router.replace('/so-sanh')
    }
  }
}
</script>
<style lang="scss">
.product__item__img {
  background-image: url('/images/product/pro_01.jpg');
  min-height: 100px;
  background-size: cover;
  background-position: center;
}
.product__item__img--04 {
  background-image: url('/images/product/pro_04.jpg');
}
.product__item__img--02 {
  background-image: url('/images/product/pro_02.jpg');
}
.product__item__img--03 {
  background-image: url('/images/product/pro_05.jpg');
}
</style>
