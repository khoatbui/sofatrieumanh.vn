<template>
  <div class="VueToNuxtLogo"></div>
</template>

<style></style>
