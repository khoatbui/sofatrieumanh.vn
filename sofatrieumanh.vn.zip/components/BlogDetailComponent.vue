<template>
  <div class="blogdetail__component">
    <div class="row mp--none category__component section__margin">
      <div
        class="col-12 col-md-10 mx-auto mp--none d-flex justify-content-center align-items-center flex-column"
      >
        <h1 class="category__name">NHAT KI NOI THAT</h1>
      </div>
    </div>
    <div class="row mp--none">
      <div class="col-12 col-md-9 mp--none pr-2">
        <div class="card border-0 mp--none">
          <div class="card-body">
            <h3 class="tintuc__title mt-4">
              <span>Get your house ready for extra guests</span>

              <span class="min__read">2 mins read</span>
            </h3>

            <div class="tintuc__info">
              <span class="creator">
                <i class="material-icons"> verified_user </i>by : namsolen</span
              >
            </div>
            <div class="tintuc__image"></div>
            <div class="tintuc__intro">
              There’s no hiding from the fact that Christmas is well and truly
              around the corner. As supermarkets line the shelves with mince
              pies and, as yet, unlit lights hang above the high street, this is
              no time to stick your head in the sand.
            </div>
            <div class="tintuc__content">
              Sooner than you think the in-laws, distant cousins and friends
              will all be coming to share in the festive cheer. To get your home
              merry-ready and help fill your guests with seasonal joy, we’ve
              brought together our favourite pieces to make your home a holiday
              hub. Patrick 2 Seat Sofa bed in Canary Cotton Matt Velvet At this
              time of year, when you’ll be entertaining more than usual, it’s
              helpful to have versatile pieces, like a sofa bed, that work for
              their spot in your home. And our Patrick is certainly doing over
              time. By day, he’s a delightfully squishy sofa, perfect for your
              friends to sink into while munching on a mince pie, but by night
              he transforms into a superbly snug bed (should they get a bit too
              merry to make it home). You deserve a raise, Patrick! Arabella
              Dining Chairs in Prussian Blue, Olive, Chicory and Orchid Cotton
              Matt Velvet Unless you’re used to hosting lavish dinner parties
              throughout the year (in which case, can we come?), chances are
              you’re going to need some extra dining pieces to accommodate all
              your loved ones when the holidays come around. Our Arabella dining
              chairs work perfectly as their comfy nature is fabulous when
              you’re lingering around the table (and very supportive when you’ve
              overloaded your plate!), but when they’re not in use they also
              make for the ideal occasional chair for anywhere in the house from
              your bedroom to the living room or hallway. Claude Loveseat in
              Peony Cotton Matt Velvet We don’t always have as much room as we’d
              like and in order to maximise the amount of guests you can fit on
              the furniture, rather than the floor, you need to be a bit clever
              with space-saving solutions. This is where the magic of a loveseat
              fully comes into its own. Cuddle up and get cosy with the same
              amount of people as you would with a sofa, all in the space of an
              armchair. With our Claude loveseat we’ve even got rid of the arms
              to make more room for your friends to sit back (or for you to curl
              up in and relax once everybody’s left).
            </div>
          </div>
        </div>
        <RequestAdvisorComponent />
      </div>
      <div class="col-md-3 mp--none pl-2">
        <div class="card border-0 mp--none mb-4">
          <div class="card-body">
            <vs-input
              v-model="value4"
              icon-after="true"
              icon="search"
              label-placeholder="Search news"
              class="w-100"
            />
          </div>
        </div>
        <div class="card border-0 mp--none">
          <div class="card-body mp--none">
            <div class="card border-0 mb-4">
              <div class="card-body">
                <div class="card border-0 mp--none hot__blog__item">
                  <div class="hot__blog__image"></div>
                  <div class="card-body mp--none">
                    <h5 class="hot__blog__title">
                      Kien truc hien dai trong noi that
                    </h5>
                    <span class="hot__blog__createtime"
                      ><i class="material-icons mx-1 text__size--x09">
                        access_time </i
                      >2019-02-15</span
                    >
                    <p class="hot__blog__intro">
                      Phòng khách có cầu thang là thiết kế phổ biến của nhà phố
                      và biệt thự hiện nay. Đây là khu vực kết nối ...
                    </p>
                    <vs-button
                      :color="'#156867'"
                      type="flat"
                      class="px-3 py-1 border__radius--100"
                      >Đọc thêm</vs-button
                    >
                  </div>
                </div>
              </div>
            </div>
            <div class="card border-0 mb-4">
              <div class="card-body">
                <div class="card border-0 mp--none hot__blog__item">
                  <div class="hot__blog__image"></div>
                  <div class="card-body mp--none">
                    <h5 class="hot__blog__title">
                      Kien truc hien dai trong noi that
                    </h5>
                    <span class="hot__blog__createtime"
                      ><i class="material-icons mx-1 text__size--x09">
                        access_time </i
                      >2019-02-15</span
                    >
                    <p class="hot__blog__intro">
                      Phòng khách có cầu thang là thiết kế phổ biến của nhà phố
                      và biệt thự hiện nay. Đây là khu vực kết nối ...
                    </p>
                    <vs-button
                      :color="'#156867'"
                      type="flat"
                      class="px-3 py-1 border__radius--100"
                      >Đọc thêm</vs-button
                    >
                  </div>
                </div>
              </div>
            </div>
            <div class="card border-0 mb-4">
              <div class="card-body">
                <div class="card border-0 mp--none hot__blog__item">
                  <div class="hot__blog__image"></div>
                  <div class="card-body mp--none">
                    <h5 class="hot__blog__title">
                      Kien truc hien dai trong noi that
                    </h5>
                    <span class="hot__blog__createtime"
                      ><i class="material-icons mx-1 text__size--x09">
                        access_time </i
                      >2019-02-15</span
                    >
                    <p class="hot__blog__intro">
                      Phòng khách có cầu thang là thiết kế phổ biến của nhà phố
                      và biệt thự hiện nay. Đây là khu vực kết nối ...
                    </p>
                    <vs-button
                      :color="'#156867'"
                      type="flat"
                      class="px-3 py-1 border__radius--100"
                      >Đọc thêm</vs-button
                    >
                  </div>
                </div>
              </div>
            </div>
            <div class="card border-0 mb-4">
              <div class="card-body">
                <div class="card border-0 mp--none hot__blog__item">
                  <div class="hot__blog__image"></div>
                  <div class="card-body mp--none">
                    <h5 class="hot__blog__title">
                      Kien truc hien dai trong noi that
                    </h5>
                    <span class="hot__blog__createtime"
                      ><i class="material-icons mx-1 text__size--x09">
                        access_time </i
                      >2019-02-15</span
                    >
                    <p class="hot__blog__intro">
                      Phòng khách có cầu thang là thiết kế phổ biến của nhà phố
                      và biệt thự hiện nay. Đây là khu vực kết nối ...
                    </p>
                    <vs-button
                      :color="'#156867'"
                      type="flat"
                      class="px-3 py-1 border__radius--100"
                      >Đọc thêm</vs-button
                    >
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import RequestAdvisorComponent from '@/components/RequestAdvisorComponent'
export default {
  components: {
    RequestAdvisorComponent
  }
}
</script>
<style lang="scss">
.tintuc {
  background-color: $white__color;
}
.tintuc__title {
  font-size: 2rem;
  position: relative;
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: $primary__color;
}
.tintuc__info {
  margin: 0 0 3.2rem 0;
}
.tintuc__info .creator {
  color: $muted__color;
  font-size: 0.8rem;
  display: none;
}
.tintuc__info .creator .material-icons {
  font-size: 01rem !important;
  color: $primary__color;
  margin-right: 0.2rem;
}
.tintuc__title .min__read {
  background-color: $primary__color;
  padding: 0.4rem 0.8rem;
  border-radius: 100px;
  font-size: 0.8rem;
  color: $white__color;
}
.tintuc__title::before {
  position: absolute;
  content: '';
  bottom: -1.6rem;
  left: 0;
  width: 40%;
  height: 4px;
  border-radius: 100px;
  background-color: $primary__color;
}
.tintuc__image {
  background-image: url('/images/blogs/blog_04.jpg');
  width: 100%;
  min-height: 300px;
  background-size: cover;
  background-position: center;
  margin: 1.6rem 0;
}
.tintuc__intro {
  font-style: italic;
  margin: 1.6rem 0;
  color: $muted__color;
  font-size: 0.9rem;
  padding: 0.8rem;
  border-left: 4px solid $muted__color;
}
.hot__blog__image {
  background-image: url('/images/blogs/blog_01.jpg');
  background-size: cover;
  min-height: 100px;
  background-position: center;
  background-repeat: no-repeat;
}
.hot__blog__title {
  font-size: 1rem;
  font-weight: bold;
  color: $primary__color;
  margin-bottom: 0.8rem;
}
.hot__blog__createtime {
  font-size: 0.8rem;
  color: $muted__color;
  margin-bottom: 0.8rem;
}
.hot__blog__intro {
  font-size: 0.9rem;
  color: $three__color;
  padding: 0;
  margin: 0;
}
</style>
