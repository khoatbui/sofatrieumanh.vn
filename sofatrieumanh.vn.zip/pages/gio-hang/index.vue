<template>
  <div class="giohang__component section__padding">
    <div class="container">
      <div class="row mp--none">
        <div class="col-12 col-md-8 mp--none p-2">
          <div class="card border-0 mp--none">
            <div class="card-body">
              <div
                class="row mp--none border p-2 align-items-center my-2 flex-wrap"
              >
                <div class="col-2 col-md-1 mp--none">
                  <vs-button
                    radius
                    :color="'#156867'"
                    size="small"
                    type="flat"
                    icon="clear"
                  ></vs-button>
                </div>
                <div class="col-6 col-md-4 mp--none">
                  <div class="cart__item__img"></div>
                </div>
                <div
                  class="col-4 col-md-3 mp--none d-flex justify-content-around align-items-center"
                >
                  <vs-button
                    radius
                    :color="'#156867'"
                    size="small"
                    type="border"
                    icon="remove"
                    class="plus__btn"
                  ></vs-button>
                  <span class="text__size--x12 font-weight-bold px-2">1</span>
                  <vs-button
                    radius
                    :color="'#156867'"
                    size="small"
                    type="border"
                    icon="add"
                    class="plus__btn"
                  ></vs-button>
                </div>
                <div
                  class="col-12 col-md-4 mp--none d-flex flex-column justify-content-center align-items-end"
                >
                  <span class="text-muted text__size--x09"> 229,000 x 3</span>
                  <strong>Tong tien: 989,000</strong>
                </div>
              </div>
              <div
                class="row mp--none border p-2 align-items-center my-2 flex-wrap"
              >
                <div class="col-2 col-md-1 mp--none">
                  <vs-button
                    radius
                    :color="'#156867'"
                    size="small"
                    type="flat"
                    icon="clear"
                  ></vs-button>
                </div>
                <div class="col-6 col-md-4 mp--none">
                  <div class="cart__item__img"></div>
                </div>
                <div
                  class="col-4 col-md-3 mp--none d-flex justify-content-around align-items-center"
                >
                  <vs-button
                    radius
                    :color="'#156867'"
                    size="small"
                    type="border"
                    icon="remove"
                    class="plus__btn"
                  ></vs-button>
                  <span class="text__size--x12 font-weight-bold px-2">1</span>
                  <vs-button
                    radius
                    :color="'#156867'"
                    size="small"
                    type="border"
                    icon="add"
                    class="plus__btn"
                  ></vs-button>
                </div>
                <div
                  class="col-12 col-md-4 mp--none d-flex flex-column justify-content-center align-items-end"
                >
                  <span class="text-muted text__size--x09"> 229,000 x 3</span>
                  <strong>Tong tien: 989,000</strong>
                </div>
              </div>
              <div
                class="row mp--none border p-2 align-items-center my-2 flex-wrap"
              >
                <div class="col-2 col-md-1 mp--none">
                  <vs-button
                    radius
                    :color="'#156867'"
                    size="small"
                    type="flat"
                    icon="clear"
                  ></vs-button>
                </div>
                <div class="col-6 col-md-4 mp--none">
                  <div class="cart__item__img"></div>
                </div>
                <div
                  class="col-4 col-md-3 mp--none d-flex justify-content-around align-items-center"
                >
                  <vs-button
                    radius
                    :color="'#156867'"
                    size="small"
                    type="border"
                    icon="remove"
                    class="plus__btn"
                  ></vs-button>
                  <span class="text__size--x12 font-weight-bold px-2">1</span>
                  <vs-button
                    radius
                    :color="'#156867'"
                    size="small"
                    type="border"
                    icon="add"
                    class="plus__btn"
                  ></vs-button>
                </div>
                <div
                  class="col-12 col-md-4 mp--none d-flex flex-column justify-content-center align-items-end"
                >
                  <span class="text-muted text__size--x09"> 229,000 x 3</span>
                  <strong>Tong tien: 989,000</strong>
                </div>
              </div>
              <div
                class="row mp--none border p-2 align-items-center my-2 flex-wrap"
              >
                <div class="col-2 col-md-1 mp--none">
                  <vs-button
                    radius
                    :color="'#156867'"
                    size="small"
                    type="flat"
                    icon="clear"
                  ></vs-button>
                </div>
                <div class="col-6 col-md-4 mp--none">
                  <div class="cart__item__img"></div>
                </div>
                <div
                  class="col-4 col-md-3 mp--none d-flex justify-content-around align-items-center"
                >
                  <vs-button
                    radius
                    :color="'#156867'"
                    size="small"
                    type="border"
                    icon="remove"
                    class="plus__btn"
                  ></vs-button>
                  <span class="text__size--x12 font-weight-bold px-2">1</span>
                  <vs-button
                    radius
                    :color="'#156867'"
                    size="small"
                    type="border"
                    icon="add"
                    class="plus__btn"
                  ></vs-button>
                </div>
                <div
                  class="col-12 col-md-4 mp--none d-flex flex-column justify-content-center align-items-end"
                >
                  <span class="text-muted text__size--x09"> 229,000 x 3</span>
                  <strong>Tong tien: 989,000</strong>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-4 mp--none p-2">
          <div class="card border-0 mp--none">
            <div class="card-body">
              <div class="row mp--none mb-4">
                <div class="col-12 mp--none">
                  <h5 class="total__title">Tong don hang</h5>
                </div>
              </div>
              <div class="row mp--none border-bottom my-3">
                <div class="col-6 mp--none text-left">
                  <p class="total__title__text text-muted">San pham 01</p>
                </div>
                <div class="col-6 mp--none text-right">
                  <p class="total__title__item">2 x 265,000</p>
                </div>
              </div>
              <div class="row mp--none border-bottom my-3">
                <div class="col-6 mp--none text-left">
                  <p class="total__title__text text-muted">San pham 02</p>
                </div>
                <div class="col-6 mp--none text-right">
                  <p class="total__title__item">2 x 265,000</p>
                </div>
              </div>
              <div class="row mp--none border-bottom my-3">
                <div class="col-6 mp--none text-left">
                  <p class="total__title__total text-muted">
                    <strong>Tong tien</strong>
                  </p>
                </div>
                <div class="col-6 mp--none text-right">
                  <p class="total__title"><strong> 2 x 265,000</strong></p>
                </div>
              </div>
              <div class="row mp--none thanhtoan__section">
                <div class="col-12 mp--none">
                  <vs-button color="warning" type="filled" class="w-100"
                    >Tien hanh thanh toan</vs-button
                  >
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  layout: 'mainlayout'
}
</script>
<style lang="scss">
.thanhtoan__section {
  margin-top: 4rem;
  margin-bottom: 1rem;
}
.total__title {
  font-size: 1.3rem;
  font-weight: bold;
  columns: $muted__color;
}
.giohang__component {
  background-color: $secondary__bg__color;
}
.cart__item__img {
  background-image: url('/images/product/pro_05.jpg');
  background-position: center;
  background-size: cover;
  background-repeat: no-repeat;
  width: 70px;
  min-height: 50px;
}
.plus__btn {
  border-radius: 50%;
  border: 2px solid $primary__color !important;
}
.plus__btn i {
  font-size: 1rem !important;
  font-weight: bold;
  color: $primary__color;
}
</style>
