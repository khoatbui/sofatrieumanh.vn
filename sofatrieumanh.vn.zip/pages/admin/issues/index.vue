<template>
  <div class="issue__blog__page"></div>
</template>
<script>
export default {
  layout: 'adminlayout'
}
</script>
