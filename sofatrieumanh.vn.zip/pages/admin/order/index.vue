<template>
  <div class="order__blog__page"></div>
</template>
<script>
export default {
  layout: 'adminlayout'
}
</script>
