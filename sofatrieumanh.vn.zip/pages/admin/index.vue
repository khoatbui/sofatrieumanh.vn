<template>
  <div class="admin__page"></div>
</template>
<script>
export default {
  layout: 'adminlayout'
}
</script>
