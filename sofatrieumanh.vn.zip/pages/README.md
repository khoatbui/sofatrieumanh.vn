# PAGES

This directory contains your Application Views and Routes.
The framework reads all the `*.vue` files inside this directory and creates the router of your application.

More information about the usage of this directory in [the documentation](https://nuxtjs.org/guide/routing).

# CAU TRUC ROUTING

|--index.html

|------danh-muc
|----------index.html

|----------ghe-sofa
|--------------index.html

|----------ban-sofa
|--------------index.html

|----------ghe-sofa-khuyen-mai
|--------------index.html

|----------sofa-thank-ly
|--------------index.html

|----------tin-tuc
|--------------index.html

|----------lien-he
|--------------index.html

|------san-pham
|----------index.html

|------about
|----------chinh-sach-bao-mat.html
|----------chinh-sach-quy-dinh.html
|----------chinh-sach-thanh-toan.html
|----------chinh-sach-doi-tra.html
|----------chinh-sach-bao-hanh.html

|------cart
|----------index.html
|----------thanh-toan.html
