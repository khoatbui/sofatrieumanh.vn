import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _e46135a0 = () => interopDefault(import('..\\pages\\admin\\index.vue' /* webpackChunkName: "pages_admin_index" */))
const _b941f660 = () => interopDefault(import('..\\pages\\danh-muc\\index.vue' /* webpackChunkName: "pages_danh-muc_index" */))
const _3d566823 = () => interopDefault(import('..\\pages\\gio-hang\\index.vue' /* webpackChunkName: "pages_gio-hang_index" */))
const _79886f44 = () => interopDefault(import('..\\pages\\san-pham\\index.vue' /* webpackChunkName: "pages_san-pham_index" */))
const _73cec7a6 = () => interopDefault(import('..\\pages\\so-sanh\\index.vue' /* webpackChunkName: "pages_so-sanh_index" */))
const _2b02a711 = () => interopDefault(import('..\\pages\\tin-tuc\\index.vue' /* webpackChunkName: "pages_tin-tuc_index" */))
const _5a871ce6 = () => interopDefault(import('..\\pages\\tu-van-thiet-ke\\index.vue' /* webpackChunkName: "pages_tu-van-thiet-ke_index" */))
const _4915b44e = () => interopDefault(import('..\\pages\\admin\\blog\\index.vue' /* webpackChunkName: "pages_admin_blog_index" */))
const _10d6c040 = () => interopDefault(import('..\\pages\\admin\\charactery\\index.vue' /* webpackChunkName: "pages_admin_charactery_index" */))
const _cae0ce94 = () => interopDefault(import('..\\pages\\admin\\issues\\index.vue' /* webpackChunkName: "pages_admin_issues_index" */))
const _75a6c671 = () => interopDefault(import('..\\pages\\admin\\menu\\index.vue' /* webpackChunkName: "pages_admin_menu_index" */))
const _1d829554 = () => interopDefault(import('..\\pages\\admin\\order\\index.vue' /* webpackChunkName: "pages_admin_order_index" */))
const _b0e8cad6 = () => interopDefault(import('..\\pages\\admin\\product\\index.vue' /* webpackChunkName: "pages_admin_product_index" */))
const _0c323be1 = () => interopDefault(import('..\\pages\\admin\\promotion\\index.vue' /* webpackChunkName: "pages_admin_promotion_index" */))
const _801d1b0e = () => interopDefault(import('..\\pages\\gio-hang\\_transactionid.vue' /* webpackChunkName: "pages_gio-hang__transactionid" */))
const _5eb8b3d5 = () => interopDefault(import('..\\pages\\thanh-toan\\_transactionid.vue' /* webpackChunkName: "pages_thanh-toan__transactionid" */))
const _89557d8a = () => interopDefault(import('..\\pages\\tin-tuc\\_tintuc\\index.vue' /* webpackChunkName: "pages_tin-tuc__tintuc_index" */))
const _18510026 = () => interopDefault(import('..\\pages\\danh-muc\\_tendanhmuc\\_id.vue' /* webpackChunkName: "pages_danh-muc__tendanhmuc__id" */))
const _63e639d6 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/admin",
    component: _e46135a0,
    name: "admin"
  }, {
    path: "/danh-muc",
    component: _b941f660,
    name: "danh-muc"
  }, {
    path: "/gio-hang",
    component: _3d566823,
    name: "gio-hang"
  }, {
    path: "/san-pham",
    component: _79886f44,
    name: "san-pham"
  }, {
    path: "/so-sanh",
    component: _73cec7a6,
    name: "so-sanh"
  }, {
    path: "/tin-tuc",
    component: _2b02a711,
    name: "tin-tuc"
  }, {
    path: "/tu-van-thiet-ke",
    component: _5a871ce6,
    name: "tu-van-thiet-ke"
  }, {
    path: "/admin/blog",
    component: _4915b44e,
    name: "admin-blog"
  }, {
    path: "/admin/charactery",
    component: _10d6c040,
    name: "admin-charactery"
  }, {
    path: "/admin/issues",
    component: _cae0ce94,
    name: "admin-issues"
  }, {
    path: "/admin/menu",
    component: _75a6c671,
    name: "admin-menu"
  }, {
    path: "/admin/order",
    component: _1d829554,
    name: "admin-order"
  }, {
    path: "/admin/product",
    component: _b0e8cad6,
    name: "admin-product"
  }, {
    path: "/admin/promotion",
    component: _0c323be1,
    name: "admin-promotion"
  }, {
    path: "/gio-hang/:transactionid?",
    component: _801d1b0e,
    name: "gio-hang-transactionid"
  }, {
    path: "/thanh-toan/:transactionid?",
    component: _5eb8b3d5,
    name: "thanh-toan-transactionid"
  }, {
    path: "/tin-tuc/:tintuc?",
    component: _89557d8a,
    name: "tin-tuc-tintuc"
  }, {
    path: "/danh-muc/:tendanhmuc?/:id",
    component: _18510026,
    name: "danh-muc-tendanhmuc-id"
  }, {
    path: "/",
    component: _63e639d6,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
