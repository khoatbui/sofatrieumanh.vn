<?php
defined('ALTUMCODE') || die();
User::check_permission(0);
