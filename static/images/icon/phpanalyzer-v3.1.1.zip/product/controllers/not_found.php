<?php
defined('ALTUMCODE') || die();

/* Set custom 404 header */
header('HTTP/1.0 404 Not Found');

$controller_has_container = false;
