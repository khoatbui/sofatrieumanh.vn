<?php
/*
 * AltumCode
 *
 *
 * @web         https://altumcode.io/
 * @twitter     https://twitter.com/altumcode
 *
 */

/* Security purpose define */
define('ALTUMCODE', true);

/* Enabling debug mode is only for debugging / development purposes. */
define('DEBUG', false);

/* Enabling mysql debug mode is only for debugging / development purposes. */
define('MYSQL_DEBUG', false);

require 'core/base.php';
